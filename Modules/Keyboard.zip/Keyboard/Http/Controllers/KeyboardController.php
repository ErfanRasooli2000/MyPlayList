<?php

namespace Modules\Keyboard\Http\Controllers;

use App\Http\Controllers\Controller;

class KeyboardController extends Controller
{
    public static function createSearchResultKeyboard($result)
    {

        $pagesCount = count($result);

        $keyboard = [];

        $result = $result->take(5);
        foreach ($result as $item)
        {
            $keyboard[] = [
                [
                    "text" => $item->artists->first()->name_en . " - " .$item->name_en,
                    "callback_data" => $item->id
                ]
            ];
        }

        $keyboard[] = [
            [
                "text" => "⏮",
                "callback_data" => "2",
            ],
            [
                "text" => "2",
                "callback_data" => "2",
            ],
            [
                "text" => "3",
                "callback_data" => "2",
            ],
            [
                "text" => "4",
                "callback_data" => "2",
            ],
            [
                "text" => "⏭",
                "callback_data" => "2",
            ],
        ];

        return [
            'inline_keyboard' => $keyboard,
            'resize_keyboard' => true
        ];
    }

    private function createPagination()
    {

    }
}
