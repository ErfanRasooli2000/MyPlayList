<?php

namespace Modules\Keyboard\Enums;

enum CallBackTypeEnum
{
    //
}
