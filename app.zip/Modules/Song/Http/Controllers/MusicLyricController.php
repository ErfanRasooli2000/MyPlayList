<?php

namespace Modules\Song\Http\Controllers;

use App\Http\Controllers\Controller;

class MusicLyricController extends Controller
{
    //
}
