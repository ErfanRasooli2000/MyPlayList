<?php

namespace Modules\PanelUser\Database\Repositories\Eloquents;

use Modules\PanelUser\Database\Repositories\Contracts\PanelUserRepositoryInterface;

class PanelUserRepository implements PanelUserRepositoryInterface
{

}
