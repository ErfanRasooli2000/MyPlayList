<?php

namespace Modules\PanelUser\Database\Repositories\Contracts;

interface PanelUserRepositoryInterface
{

}
