<?php

namespace Modules\PlayList\Http\Controllers;

use App\Http\Controllers\Controller;

class PlaylistController extends Controller
{
    //
}
