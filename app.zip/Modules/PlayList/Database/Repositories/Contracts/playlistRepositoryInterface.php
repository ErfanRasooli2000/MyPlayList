<?php

namespace Modules\PlayList\Database\Repositories\Contracts;

interface playlistRepositoryInterface
{
    public function create($validated);
}
