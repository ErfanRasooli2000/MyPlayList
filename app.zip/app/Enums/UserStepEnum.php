<?php

namespace App\Enums;

enum UserStepEnum:string
{
    case Search = "Search";
    case NewPlayList = "NewPlayList";
}
